# fixApi

fixApi交互式测试客户端

## Getting started
    1.在config文件夹下配置好对应环境的cfg文件和yml文件，并修改client.py中的version，env变量
    
    2.运行客户端文件（如果缺少必要包执行3安装包）
    python3 client.py 
    
    3.使用如下命令安装必要依赖包
    pip install 包名 -i http://172.28.25.12:8081/repository/pypi-group/simple --trusted-host 172.28.25.12
   