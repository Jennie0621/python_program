import datetime
import csv
import time
import uuid
import quickfix as fix
from util.parase_ import transfer
from pathlib import Path
import quickfix50sp2 as fix44  # 支持fix50sp2

projectPath = Path.cwd()
casePath = projectPath.joinpath("case", "caseData.csv")
reportPath = projectPath.joinpath("report", "report.csv")
configPath = str(projectPath.joinpath("config", "pst_fix50.cfg"))

version = "FIX50SP2"
# version = "FIX44"
if version == "FIX44":
    import quickfix44 as fix44  # 支持fix50sp2, fix44
    configPath = str(projectPath.joinpath("config", "pst_fix44.cfg"))


class Application(fix.Application):

    sessionID1 = None
    sessionID2 = None
    sessionID3 = None
    sessionID4 = None

    def onCreate(self, sessionID: fix.SessionID):
        print(f"onCreate:{sessionID}")

    def onLogon(self, sessionID: fix.SessionID):
        print(f"onLogon:{sessionID}")
        if sessionID.toString().endswith("TradingGateway"):
            if self.sessionID1:
                self.sessionID2 = sessionID
            else:
                self.sessionID1 = sessionID
        elif self.sessionID3:
            self.sessionID4 = sessionID
        else:
            self.sessionID3 = sessionID


    def onLogout(self, sessionID: fix.SessionID):
        print(f"onLogout: {sessionID}")

    def toAdmin(self, message: fix.Message, sessionID: fix.SessionID):
        print(f"toAdmin: {message}")
        MsgType = message.getHeader().getField(fix.MsgType().getField())
        if MsgType == "A":
            username = str(sessionID).split("->")[0].split(":")[1]
            message.setField(fix.Username(username))
            if username == "123":
                message.setField(fix.Password("123"))
            if username == "321":
                message.setField(fix.Password("321"))
        elif MsgType == "3":  # session拒绝回报
            print(f"拒绝原因：【{message.getField(fix.RefTagID().getField())}-{message.getField(fix.Text().getField())}】")

    def fromAdmin(self, message: fix.Message, sessionID: fix.SessionID):
        print(f"fromAdmin: {message.toString()}")

    def toApp(self, message: fix.Message, sessionID: fix.SessionID):
        print(f"ToApp: {message.toString()}")

    def fromApp(self, message: fix.Message, sessionID: fix.SessionID):
        # print("11111111", sessionID)
        # print(f" 原始返回: {message}")
        content = transfer(message.toString())
        self.writeMessage(content)
        print(f" FromApp: {content}")
        # MsgType = message.getHeader().getField(fix.MsgType().getField())
        # if MsgType == "j":  # 报单业务拒绝回报
        #     print(f"回报原因：拒绝原因-【{message.getField(fix.Text().getField())}】")
        # elif MsgType == "8":  # 核心订单回报
        #     if message.getField(fix.OrdStatus().getField()) == "0":  # 订单状态-New
        #         if message.getField(fix.OrdType().getField()) == "1":  # 市价单
        #             print(f"下单(部分撤单)成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
        #         if message.getField(fix.OrdType().getField()) == "2":  # 限价单
        #             print(f"下单(部分撤单)成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")
        #
        #     elif message.getField(fix.OrdStatus().getField()) == "1":  # 订单状态-Partially fille
        #         if message.getField(fix.OrdType().getField()) == "1":  # 市价单
        #             print(f"下单成功-部分成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
        #         if message.getField(fix.OrdType().getField()) == "2":  # 限价单
        #             print(f"下单成功-部分成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")
        #
        #     elif message.getField(fix.OrdStatus().getField()) == "2":  # 订单状态-Fille
        #         if message.getField(fix.OrdType().getField()) == "1":  # 市价单
        #             print(f"下单成功-全部成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
        #         if message.getField(fix.OrdType().getField()) == "2":  # 限价单
        #             print(f"下单成功-全部成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")
        #
        #     elif message.getField(fix.OrdStatus().getField()) == "4":  # 订单状态-Cancelled
        #         if message.getField(fix.OrdType().getField()) == "1":  # 市价单
        #             print(f"撤单成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
        #         if message.getField(fix.OrdType().getField()) == "2":  # 限价单
        #             print(f"撤单成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")
        #
        #     elif message.getField(fix.OrdStatus().getField()) == "8":  # 订单状态-Rejected
        #         print(f"核心拒绝：订单号-【{message.getField(fix.OrderID().getField())}】，拒绝原因-【{message.getField(fix.Text().getField())}】")
        # elif MsgType == "AP":  # 资产查询回报
        #     print(f"资产详情：账户-【{message.getField(fix.Account().getField())}】")
        # elif MsgType == "9":  # 撤单拒绝回报
        #     print(f"撤单拒绝：拒绝原因-【{message.getField(fix.Text().getField())}】")

    # MsgType <35>=D  报单
    def createOrder(self, sessionID, Symbol, OrderQty, *args):
        Side = "2"
        Account = None
        Price = None
        for item in args:
            k, v = item.split("=")
            if k == 'Side':
                Side = v
            elif k == 'Account':
                Account = v
            elif k == 'Price':
                Price = v
        print("Creating the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("D"))  # 请求类型
        message.setField(11, id)  # 请求id  order_local_id
        message.setField(55, Symbol)  # 交易产品
        message.setField(38, OrderQty)  # 订单数量
        if Price:
            message.setField(44, Price)  # 报单价格
            message.setField(40, "2")  # 订单类型 限价单2
        else:
            message.setField(40, "1")  # 订单类型 市价单1
        if Account:
            message.setField(1, Account)  # 可以指定子账户下单
        message.setField(54, Side)  # 买卖方向 买1 卖2
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        print("报单参数： ", message.toString())
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=F
    def cancelOrder(self, sessionID, OrderID, *args):
        OrderQty = None
        OrigCIOrdID = None
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'OrderQty':
                OrderQty = v
            elif k == 'Account':
                Account = v
            elif k == 'OrigCIOrdID':
                OrigCIOrdID = v
        print("Cancel the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("F"))  # 请求类型
        message.setField(11, id)  # 请求id，
        if OrigCIOrdID:
            message.setField(41, OrigCIOrdID)  # 订单id， order_local_id
        message.setField(37, OrderID)  # 订单id， order_sys_id
        if OrderQty:
            message.setField(38, OrderQty)  # 订单数量
        if Account:
            message.setField(1, Account)  # 指定交易账户
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=q
    def cancelAllOrder(self, sessionID, CancelType, *args):
        Symbol = None
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'CancelType':
                CancelType = v
            elif k == 'Account':
                Account = v
            elif k == 'Symbol':
                Symbol = v
        print("Cancel the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("q"))  # 请求类型
        message.setField(11, id)  # 请求id，
        message.setField(530, CancelType)  # 默认7,当前委托单全部撤销
        if Account:
            message.setField(1, Account)  # 指定交易账户
        if CancelType == '3':
            try:
                message.setField(55, Symbol)  # 按指定合约撤单3
            except ValueError:
                print(f"CancelType={CancelType}时，Symbol必填，请检查参数，重新输入")
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=AN
    def queryPosition(self, sessionID, SRT, *args):
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'Account':
                Account = v
        print("Query the following position: ")
        ud = str(uuid.uuid1()).split("-")
        PosReqID = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("AN"))  # 请求类型
        message.setField(710, PosReqID)  # 请求id，
        message.setField(724, "0")  # 当前只有0–Positions
        message.setField(263, SRT)  # 要求服务端返回的类型，可以填 0–Snapshot，1–Snapshot+Updates，2-Disable previous Snapshot+Update Request
        if Account:
            message.setField(1, Account)
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=G
    def actionOrder(self, sessionID, OrderID, OrderQty, *args):
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'Account':
                Account = v
        print("Update the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("G"))  # 请求类型
        message.setField(11, id)  # 请求id，
        message.setField(37, OrderID)  # 订单id， order_sys_id
        message.setField(38, OrderQty)  # 订单数量
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        if Account:
            message.setField(1, Account)  # 指定交易账户
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType < 35 > = 2
    def resendRequest(self, sessionID, BeginSeqNo, EndSeqNo):
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("2"))  # 请求类型
        message.setField(7, BeginSeqNo)  # 起始 SeqNo
        message.setField(16, EndSeqNo)  # 截止 SeqNo
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35> =V
    def marketDataRequest(self, sessionID, SRT, MDType, Sym, *args):
        MDUpdateType = None
        for item in args:
            k, v = item.split("=")
            if k == 'MDUpdateType':
                MDUpdateType = v
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix44.MarketDataRequest()
        group = fix44.MarketDataRequest().NoMDEntryTypes()  # Tag=267
        group2 = fix44.MarketDataRequest().NoRelatedSym()   #  Tag=146
        header = message.getHeader()
        header.setField(fix.MsgType("V"))  #
        message.setField(262, id)  #
        message.setField(263, SRT)  # 要求服务端返回的类型，可以填 0–Snapshot，1–Snapshot+Updates，2-Disable previous Snapshot+Update Request
        message.setField(264, '0')  # 最高50档
        if SRT == "1":
            try:
                message.setField(265, MDUpdateType)  # 0 = Full Refresh，1 = Incremental Refresh
            except ValueError:
                print(f"SRT={SRT}时，MDUpdateType必填，请检查参数，重新输入")

        MDEntryTypes = MDType.split(";")
        for MDEntryType in MDEntryTypes:
            MDEntryType = MDEntryType.replace("[", "").replace("]", "")
            group.setField(fix.MDEntryType(MDEntryType))
            message.addGroup(group)

        Symbols = Sym.split(";")
        for Symbol in Symbols:
            Symbol = Symbol.replace("[", "").replace("]", "")
            group2.setField(fix.Symbol(Symbol))
            message.addGroup(group2)

        if sessionID == "3":
            fix.Session.sendToTarget(message, self.sessionID3)
        if sessionID == "4":
            fix.Session.sendToTarget(message, self.sessionID4)

    def writeMessage(self, message):
        global current_case
        fieldnames = ['caseNO', 'isRun', 'version', 'sessionID', 'caseName', 'caseType', 'param', 'expectedResult',
                      'realResults', 'isPass']
        with open(reportPath, 'a+', newline='') as f:
            rsp = csv.DictWriter(f, fieldnames=fieldnames)
            current_case.update({'realResults': message})
            rsp.writerow(current_case)


if __name__ == '__main__':
    settings = fix.SessionSettings(configPath)
    application = Application()
    storeFactory = fix.FileStoreFactory(settings)
    logFactory = fix.FileLogFactory(settings)
    initiator = fix.SSLSocketInitiator(application, storeFactory, settings, logFactory)
    initiator.start()
    time.sleep(15)
    with open(reportPath, 'w') as file:
        fieldnames = """'caseNO', 'isRun', 'version', 'sessionID', 'caseName', 'caseType', 'param', 'expectedResult',
                      'realResults', 'isPass'\n"""
        file.write(fieldnames)

    current_case = None

    with open(casePath) as f:
        cases = csv.DictReader(f)
        for case in cases:
            time.sleep(2)
            current_case = case
            if case["isRun"] == "Y":
                caseType = case["caseType"].split("-")[1]
                sessionID = case["sessionID"]
                if caseType == "1":
                    """报单"""
                    params = case["param"].split("|")
                    if len(params) == 2:
                        Symbol, OrderQty = params
                        application.createOrder(sessionID, Symbol, OrderQty)
                    elif len(params) == 3:
                        Symbol, OrderQty, a = params
                        application.createOrder(sessionID, Symbol, OrderQty, a)
                    elif len(params) == 4:
                        Symbol, OrderQty, a, b = params
                        application.createOrder(sessionID, Symbol, OrderQty, a, b)
                    elif len(params) == 5:
                        Symbol, OrderQty, a, b, c = params
                        application.createOrder(sessionID, Symbol, OrderQty, a, b, c)
                elif caseType == "2":
                    """撤单"""
                    params = case["param"].split("|")
                    if len(params) == 1:
                        OrderID = params[0]
                        application.cancelOrder(sessionID, OrderID)
                    elif len(params) == 2:
                        OrderID, a = params
                        application.cancelOrder(sessionID, OrderID, a)
                    elif len(params) == 3:
                        OrderID, a, b = params
                        application.cancelOrder(sessionID, OrderID, a, b)
                    elif len(params) == 4:
                        OrderID, a, b, c = params
                        application.cancelOrder(sessionID, OrderID, a, b, c)
                elif caseType == "3":
                    """全部撤单"""
                    params = case["param"].split("|")
                    if len(params) == 1:
                        CancelType = params[0]
                        application.cancelAllOrder(sessionID, CancelType)
                    elif len(params) == 2:
                        CancelType, a = params
                        application.cancelAllOrder(sessionID, CancelType, a)
                    elif len(params) == 3:
                        CancelType, a, b = params
                        application.cancelAllOrder(sessionID, CancelType, a, b)
                elif caseType == "4":
                    """资产查询"""
                    params = case["param"].split("|")
                    if len(params) == 1:
                        SRT = params[0]
                        application.queryPosition(sessionID, SRT)
                    elif len(params) == 2:
                        SRT, Account = params
                        application.queryPosition(sessionID, SRT, Account)
                elif caseType == "5":
                    """部分撤单"""
                    params = case["param"].split("|")
                    if len(params) == 2:
                        OrderID, OrderQty = params
                        application.actionOrder(sessionID, OrderID, OrderQty)
                    elif len(params) == 3:
                        OrderID, OrderQty, a = params
                        application.actionOrder(sessionID, OrderID, OrderQty, a)
                elif caseType == "6":
                    """重新订阅"""
                    params = case["param"].split("|")
                    if len(params) == 2:
                        BeginSeqNo, EndSeqNo = params
                        application.resendRequest(sessionID, BeginSeqNo, EndSeqNo)
                elif caseType == "7":
                    """行情订阅"""
                    params = case["param"].split("|")
                    if len(params) == 3:
                        SRT, MDEntryType, Symbol = params
                        application.marketDataRequest(sessionID, SRT, MDEntryType, Symbol)
                    elif len(params) == 4:
                        SRT, MDEntryType, Symbol, a = params
                        application.marketDataRequest(sessionID, SRT, MDEntryType, Symbol, a)
            else:
                print(f"""{case["caseNo"]}跳过执行""")

        while True:
            time.sleep(10)