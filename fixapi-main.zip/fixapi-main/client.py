import datetime
import time
import uuid
import sys
import quickfix as fix
from util.parase_ import transfer
from pathlib import Path
import yaml
with open("./config/login.yml", "r") as f:
    config = yaml.safe_load(f)

projectPath = Path.cwd()
casePath = projectPath.joinpath("case", "caseData.csv")
reportPath = projectPath.joinpath("report", "report.csv")


"""版本控制"""
version = "FIX50SP2"
# version = "FIX44"

"""环境控制"""
env = "PST"


if version == "FIX44":
    import quickfix44 as fix44  # 支持fix50sp2, fix44
    configPath = str(projectPath.joinpath("config", f"{env.lower()}_fix44.cfg"))
else:
    import quickfix50sp2 as fix44
    configPath = str(projectPath.joinpath("config", f"{env.lower()}_fix50.cfg"))


login_infos = [(config.get(f"{env}_SESSION1").get("UserName"), config.get(f"{env}_SESSION1").get("PassWord")), (config.get(f"{env}_SESSION2").get("UserName"), config.get(f"{env}_SESSION2").get("PassWord")),(config.get(f"{env}_SESSION3").get("UserName"), config.get(f"{env}_SESSION3").get("PassWord")),(config.get(f"{env}_SESSION4").get("UserName"), config.get(f"{env}_SESSION4").get("PassWord"))]



class Application(fix.Application):
    sessionID1 = None
    sessionID2 = None
    sessionID3 = None
    sessionID4 = None

    def onCreate(self, sessionID: fix.SessionID):
        print(f"onCreate:{sessionID}")

    def onLogon(self, sessionID: fix.SessionID):
        print(f"onLogon:{sessionID}")
        if sessionID.toString().endswith("TradingGateway"):
            if self.sessionID1:
                self.sessionID2 = sessionID
            else:
                self.sessionID1 = sessionID
        elif self.sessionID3:
            self.sessionID4 = sessionID
        else:
            self.sessionID3 = sessionID

    def onLogout(self, sessionID: fix.SessionID):
        print(f"onLogout: {sessionID}")

    def toAdmin(self, message: fix.Message, sessionID: fix.SessionID):
        print(f"toAdmin: {message}")
        MsgType = message.getHeader().getField(fix.MsgType().getField())
        if MsgType == "A":
            username, password = login_infos.pop()
            message.setField(fix.Username(username))
            message.setField(fix.Password(password))

        elif MsgType == "3":  # session拒绝回报
            print(f"拒绝原因：【{message.getField(fix.RefTagID().getField())}-{message.getField(fix.Text().getField())}】")

    def fromAdmin(self, message: fix.Message, sessionID: fix.SessionID):
        print(f"fromAdmin: {message.toString()}")

    def toApp(self, message: fix.Message, sessionID: fix.SessionID):
        print(f"ToApp: {message.toString()}")

    def fromApp(self, message: fix.Message, sessionID: fix.SessionID):
        print(f" 原始返回: {message}")
        content = transfer(message.toString())
        print(f" FromApp: {content}")
        MsgType = message.getHeader().getField(fix.MsgType().getField())
        if MsgType == "j":  # 报单业务拒绝回报
            print(f"回报原因：拒绝原因-【{message.getField(fix.Text().getField())}】")
        elif MsgType == "8":  # 核心订单回报
            if message.getField(fix.OrdStatus().getField()) == "0":  # 订单状态-New
                if message.getField(fix.OrdType().getField()) == "1":  # 市价单
                    print(f"下单(部分撤单)成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
                if message.getField(fix.OrdType().getField()) == "2":  # 限价单
                    print(f"下单(部分撤单)成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")

            elif message.getField(fix.OrdStatus().getField()) == "1":  # 订单状态-Partially fille
                if message.getField(fix.OrdType().getField()) == "1":  # 市价单
                    print(f"下单成功-部分成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
                if message.getField(fix.OrdType().getField()) == "2":  # 限价单
                    print(f"下单成功-部分成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")

            elif message.getField(fix.OrdStatus().getField()) == "2":  # 订单状态-Fille
                if message.getField(fix.OrdType().getField()) == "1":  # 市价单
                    print(f"下单成功-全部成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
                if message.getField(fix.OrdType().getField()) == "2":  # 限价单
                    print(f"下单成功-全部成交：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")

            elif message.getField(fix.OrdStatus().getField()) == "4":  # 订单状态-Cancelled
                if message.getField(fix.OrdType().getField()) == "1":  # 市价单
                    print(f"撤单成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】")
                if message.getField(fix.OrdType().getField()) == "2":  # 限价单
                    print(f"撤单成功：订单号-【{message.getField(fix.OrderID().getField())}】，合约-【{message.getField(fix.Symbol().getField())}】，下单数量-【{message.getField(fix.OrderQty().getField())}】，剩余数量-【{message.getField(fix.LeavesQty().getField())}】,价格-【{message.getField(fix.Price().getField())}】")

            elif message.getField(fix.OrdStatus().getField()) == "8":  # 订单状态-Rejected
                print(f"核心拒绝：订单号-【{message.getField(fix.OrderID().getField())}】，拒绝原因-【{message.getField(fix.Text().getField())}】")
        elif MsgType == "AP":  # 资产查询回报
            print(f"资产详情：账户-【{message.getField(fix.Account().getField())}】")
        elif MsgType == "9":  # 撤单拒绝回报
            print(f"撤单拒绝：拒绝原因-【{message.getField(fix.Text().getField())}】")


    # MsgType <35>=D
    def createOrder(self, sessionID, Symbol, OrderQty, *args):
        Side = "2"
        Account = None
        Price = None
        for item in args:
            print(item)
            k, v = item.split("=")
            if k == 'Side':
                Side = v
            elif k == 'Account':
                Account = v
            elif k == 'Price':
                Price = v
        print("Creating the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("D"))  # 请求类型
        message.setField(11, id)  # 请求id  order_local_id
        message.setField(55, Symbol)  # 交易产品
        message.setField(38, OrderQty)  # 订单数量
        if Price:
            message.setField(44, Price)  # 报单价格
            message.setField(40, "2")  # 订单类型 限价单2
        else:
            message.setField(40, "1")  # 订单类型 市价单1
        if Account:
            message.setField(1, Account)  # 可以指定子账户下单
        message.setField(54, Side)  # 买卖方向 买1 卖2
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        print("报单参数： ", message.toString())
        if sessionID == "1":
            print("------------------>", self.sessionID1)
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            print("------------------>", self.sessionID2)
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=F
    def cancelOrder(self, sessionID, OrderID, *args):
        OrderQty = None
        OrigCIOrdID = None
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'OrderQty':
                OrderQty = v
            elif k == 'Account':
                Account = v
            elif k == 'OrigCIOrdID':
                OrigCIOrdID = v
        print("Cancel the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("F"))  # 请求类型
        message.setField(11, id)  # 请求id，
        if OrigCIOrdID:
            message.setField(41, OrigCIOrdID)  # 订单id， order_local_id
        message.setField(37, OrderID)  # 订单id， order_sys_id
        if OrderQty:
            message.setField(38, OrderQty)  # 订单数量
        if Account:
            message.setField(1, Account)  # 指定交易账户
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=q
    def cancelAllOrder(self, sessionID, CancelType, *args):
        Symbol = None
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'CancelType':
                CancelType = v
            elif k == 'Account':
                Account = v
            elif k == 'Symbol':
                Symbol = v
        print("Cancel the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("q"))  # 请求类型
        message.setField(11, id)  # 请求id，
        message.setField(530, CancelType)  # 默认7,当前委托单全部撤销
        if Account:
            message.setField(1, Account)  # 指定交易账户
        if CancelType == '3':
            try:
                message.setField(55, Symbol)  # 按指定合约撤单3
            except ValueError:
                print(f"CancelType={CancelType}时，Symbol必填，请检查参数，重新输入")
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=AN
    def queryPosition(self, sessionID, SRT, *args):
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'Account':
                Account = v
        print("Query the following position: ")
        ud = str(uuid.uuid1()).split("-")
        PosReqID = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("AN"))  # 请求类型
        message.setField(710, PosReqID)  # 请求id，
        message.setField(724, "0")  # 当前只有0–Positions
        message.setField(263, SRT)  # 要求服务端返回的类型，可以填 0–Snapshot，1–Snapshot+Updates，2-Disable previous Snapshot+Update Request
        if Account:
            message.setField(1, Account)
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35>=G
    def actionOrder(self, sessionID, OrderID, OrderQty, *args):
        Account = None
        for item in args:
            k, v = item.split("=")
            if k == 'Account':
                Account = v


        print("Update the following order: ")
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("G"))  # 请求类型
        message.setField(11, id)  # 请求id，
        message.setField(37, OrderID)  # 订单id， order_sys_id
        message.setField(38, OrderQty)  # 订单数量
        message.setField(60, datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S:%f")[:-3])  # 下单时间
        if Account:
            message.setField(1, Account)  # 指定交易账户
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType < 35 > = 2
    def resendRequest(self, sessionID, BeginSeqNo, EndSeqNo):
        message = fix.Message()
        header = message.getHeader()
        header.setField(fix.MsgType("2"))  # 请求类型
        message.setField(7, BeginSeqNo)  # 起始 SeqNo
        message.setField(16, EndSeqNo)  # 截止 SeqNo
        if sessionID == "1":
            fix.Session.sendToTarget(message, self.sessionID1)
        if sessionID == "2":
            fix.Session.sendToTarget(message, self.sessionID2)

    # MsgType <35> =V
    def marketDataRequest(self, sessionID, SRT, MDType, Sym, *args):
        MDUpdateType = None
        for item in args:
            k, v = item.split("=")
            if k == 'MDUpdateType':
                MDUpdateType = v
        ud = str(uuid.uuid1()).split("-")
        id = ud[0] + ud[3]
        message = fix44.MarketDataRequest()
        group = fix44.MarketDataRequest().NoMDEntryTypes()  # Tag=267
        group2 = fix44.MarketDataRequest().NoRelatedSym()   #  Tag=146
        header = message.getHeader()
        header.setField(fix.MsgType("V"))  #
        message.setField(262, id)  #
        message.setField(263, SRT)  # 要求服务端返回的类型，可以填 0–Snapshot，1–Snapshot+Updates，2-Disable previous Snapshot+Update Request
        message.setField(264, '0')  # 最高50档
        if SRT == "1":
            try:
                message.setField(265, MDUpdateType)  # 0 = Full Refresh，1 = Incremental Refresh
            except ValueError:
                print(f"SRT={SRT}时，MDUpdateType必填，请检查参数，重新输入")

        MDEntryTypes = MDType.split(";")
        for MDEntryType in MDEntryTypes:
            MDEntryType = MDEntryType.replace("[", "").replace("]", "")
            group.setField(fix.MDEntryType(MDEntryType))
            message.addGroup(group)

        Symbols = Sym.split(";")
        for Symbol in Symbols:
            Symbol = Symbol.replace("[", "").replace("]", "")
            group2.setField(fix.Symbol(Symbol))
            message.addGroup(group2)

        if sessionID == "3":
            fix.Session.sendToTarget(message, self.sessionID3)
        if sessionID == "4":
            fix.Session.sendToTarget(message, self.sessionID4)


def main(config_file):
    try:
        settings = fix.SessionSettings(config_file)
        application = Application()
        storeFactory = fix.FileStoreFactory(settings)
        logFactory = fix.FileLogFactory(settings)
        # initiator = fix.SocketInitiator(application, storeFactory, settings, logFactory)
        initiator = fix.SSLSocketInitiator(application, storeFactory, settings, logFactory)
        initiator.start()

        while True:
            comd = input("请输入指令代码：报单-【1】，撤单-【2】，全部撤单-【3】，资产查询-【4】,部分撤单-【5】,重新订阅-【6】,行情订阅-【7】\n")
            if comd == '1':
                while True:
                    time.sleep(0.3)
                    comd = input("请输入报单参数并逗号隔开：合约-【必填】，订单数量-【必填】，买卖方向Side=-【选填，默认2卖出】，交易账户Account=-【选填】，价格Price=-【选填】，Enter-【Enter返回上一级】\n")
                    if comd:
                        params = comd.split(",")
                        if len(params) == 3:
                            sessionID, Symbol, OrderQty = params
                            application.createOrder(sessionID, Symbol, OrderQty)
                        elif len(params) == 4:
                            sessionID, Symbol, OrderQty, a = params
                            application.createOrder(sessionID, Symbol, OrderQty, a)
                        elif len(params) == 5:
                            sessionID, Symbol, OrderQty, a, b = params
                            application.createOrder(sessionID, Symbol, OrderQty, a, b)
                        elif len(params) == 6:
                            sessionID, Symbol, OrderQty, a, b, c = params
                            application.createOrder(sessionID, Symbol, OrderQty, a, b, c)
                        else:
                            print("缺少必填参数或传参太多")
                    else:
                        break
            if comd == '2':
                while True:
                    time.sleep(0.3)
                    comd = input("请输入撤单参数并逗号隔开：订单id-【必填】，订单数量OrderQty=-【选填】，订单local_id-OrigCIOrdID=【选填】，交易账户Account=-【选填】，Enter-【Enter返回上一级】\n")
                    if comd:
                        params = comd.split(",")
                        if len(params) == 2:
                            sessionID, OrderID = params
                            application.cancelOrder(sessionID, OrderID)
                        elif len(params) == 3:
                            sessionID, OrderID, a = params
                            application.cancelOrder(sessionID, OrderID, a)
                        elif len(params) == 4:
                            sessionID, OrderID, a, b = params
                            application.cancelOrder(sessionID, OrderID, a, b)
                        elif len(params) == 5:
                            sessionID, OrderID, a, b, c = params
                            application.cancelOrder(sessionID, OrderID, a, b, c)
                        else:
                            print("缺少必填参数或传参太多")
                    else:
                        break
            if comd == '3':
                while True:
                    time.sleep(0.3)
                    comd = input("请输入全部撤单键值参数并逗号隔开：撤单类型-【必填7，3】，指定合约Symbol=-【选填，当CancelType=3必填】，指定交易账户Account=-【选填】，Enter-【Enter返回上一级】\n")
                    if comd:
                        params = comd.split(",")
                        if len(params) == 2:
                            sessionID, CancelType = params
                            application.cancelAllOrder(sessionID, CancelType)
                        elif len(params) == 3:
                            sessionID, CancelType, a = params
                            application.cancelAllOrder(sessionID, CancelType, a)
                        elif len(params) == 4:
                            sessionID, CancelType, a, b = params
                            application.cancelAllOrder(sessionID, CancelType, a, b)
                        else:
                            print("缺少必填参数或传参太多")
                    else:
                        break
            if comd == '4':
                while True:
                    time.sleep(0.3)
                    comd = input("请输入资产查询参数并逗号隔开：SRT-【必填0，1，2】，指定交易账户Account=-【选填】，Enter-【Enter返回上一级】\n")
                    if comd:
                        params = comd.split(",")
                        if len(params) == 2:
                            sessionID, SRT = params
                            application.queryPosition(sessionID, SRT)
                        elif len(params) == 3:
                            sessionID, SRT, Account = params
                            application.queryPosition(sessionID, SRT, Account)
                        else:
                            print("缺少必填参数或传参太多")
                    else:
                        break
            if comd == '5':
                while True:
                    time.sleep(0.3)
                    comd = input("请输入改单参数并逗号隔开：订单id-【必填】，订单数量OrderQty-【必填】，交易账户Account=-【选填】，Enter-【Enter返回上一级】\n")
                    if comd:
                        params = comd.split(",")
                        if len(params) == 3:
                            sessionID, OrderID, OrderQty = params
                            application.actionOrder(sessionID, OrderID, OrderQty)
                        elif len(params) == 4:
                            sessionID, OrderID, OrderQty, a = params
                            application.actionOrder(sessionID, OrderID, OrderQty, a)
                        else:
                            print("缺少必填参数或传参太多")
                    else:
                        break
            if comd == '6':
                while True:
                    time.sleep(0.3)
                    comd = input("请输入改单参数并逗号隔开：开始SeqNo-【必填】，截止SeqNo-【必填】，Enter-【Enter返回上一级】\n")
                    if comd:
                        params = comd.split(",")
                        if len(params) == 3:
                            sessionID, BeginSeqNo, EndSeqNo = params
                            application.resendRequest(sessionID, BeginSeqNo, EndSeqNo)
                        else:
                            print("缺少必填参数或传参太多")
                    else:
                        break
            if comd == '7':
                while True:
                    time.sleep(0.3)
                    comd = input(
                        "请输入行情订阅参数并逗号隔开：SRT-【必填0，1，2】，MDEntryType-【必填,多值[0;1]】，Symbol-【必填,多值[BTC-USD;ETH-USD]】，MDUpdateType=-【选填0，1,当SRT=1必填】，Enter-【Enter返回上一级】\n")
                    if comd:
                        params = comd.split(",")
                        if len(params) == 4:
                            sessionID, SRT, MDEntryType, Symbol = params
                            application.marketDataRequest(sessionID, SRT, MDEntryType, Symbol)
                        elif len(params) == 5:
                            sessionID, SRT, MDEntryType, Symbol, a = params
                            application.marketDataRequest(sessionID, SRT, MDEntryType, Symbol, a)
                        else:
                            print("请检查参数，重新输入")
                    else:
                        break
            if comd == '8':
                sys.exit(0)
    except fix.ConfigError as e:
        print(e)

if __name__=='__main__':
    main(configPath)
